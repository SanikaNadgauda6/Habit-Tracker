const Post = require('../models/post');
const Comment = require('../models/comments');
const Like = require('../models/likes');

// Assuming you have imported the necessary modules and set up the Post model correctly.

module.exports.create = async function(req, res) {
  try{
  let post = await Post.create({
        content: req.body.content,
        user: req.user._id
      });

      if(req.xhr){
        post = await post.populate('user', 'name').execPopulate();

        req.flash('success', 'Post Created succesfully!');
        return res.status(200).json({
          message: "Post created successfully"
        });
      }
  }
catch(err){
    // console.log('Error in creating the post:', err);
    req.flash('error', 'Cannot post!');

    // Handle the error and send an appropriate response to the client
    return res.status(500).json({ error: 'Error creating the post' });
  }
}




module.exports.destroy = async function(req, res) {
  try{
    let post = await Post.findById(req.params.id);
    if(post.user == req.user.id){  
  
      await Like.deleteMany({likeable: post, onModel: 'Post'});
      await Like.deleteMany({_id: {in: post.comments}});

  
      post.deleteOne();
      await Comment.deleteMany({post: req.params.id})


      if (req.xhr){
        return res.status(200).json({
            data: {
                post_id: req.params.id
            },
            message: "Post deleted"
        });
      }


  
      req.flash('success', 'Post Deleted succesfully!');
      return res.redirect('back');
    }

  }
  catch(err){
      req.flash('error', 'You cannot delete the post!');
      return res.redirect('back');

  }
}

