const mongoose = require('mongoose');

const friendshipSchema = new mongoose.Schema({
    //the user who sent the req
    from_user:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    //the user who accepted this req , the namingis just to understand , other wise user's wont see the diff
    to_user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }
},{
    Timestamps: true
});

const Friendship = mongoose.model('Friendship', friendshipSchema);
module.exports = Friendship;