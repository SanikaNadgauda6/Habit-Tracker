const express = require('express');
const router = express.Router();
console.log('post router loaded');
const passport = require('passport');

const commentsController = require('../controllers/comments_controller');


router.post('/create', passport.checkAuthentication, commentsController.create);
router.get('/destroy/:id', passport.checkAuthentication, commentsController.destroy);
module.exports = router;