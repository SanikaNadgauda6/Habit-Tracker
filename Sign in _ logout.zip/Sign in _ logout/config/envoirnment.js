const development = {
    name: 'development',
    asset_path : './assets',
    session_cookie_key : 'something',
    db: 'codeial_development',
    smtp : {
        service: 'gmail',
        host: 'smtp.gmail.com',
        post: 587,
        secure: false,
        auth: {
            user: 'snadgauda17@gmail.com',
            pass: 'fnbikgrpqgjnypob'
        }
    },
    google_client_id :"751026183467-2ov3g4sakmb3j7pbgesj2j8gnlecbviu.apps.googleusercontent.com",
    google_client_secret: "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",
    google_call_back_url: "http://localhost:8000/users/auth/google/callback",
    jwt_secret : 'codeial'
    
}

const production = {
    name : 'production',
    asset_path : process.env.asset_path,
    session_cookie_key : process.env.session_cookie_key,
    db: process.env.db,
    smtp : {
        service: 'gmail',
        host: 'smtp.gmail.com',
        post: 587,
        secure: false,
        auth: {
            user: process.env.auth_user,
            pass: process.env.pass
        }
    },
    google_client_id : process.env.google_client_id,
    google_client_secret: process.env.google_client_secret,
    google_call_back_url: process.env.google_call_back_url,
    jwt_secret : process.env.jwt_secret,
}

module.exports = eval(process.env.Codial_environment) == undefined ? development : eval(process.env.Codial_environment);