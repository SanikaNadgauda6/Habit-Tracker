const Comment = require('../models/comments');
const Post = require('../models/post');
const commentsMailer = require('../mailers/comments_mailers');
const commentEmailWorker = require('../workers/comment_email_worker');
const queue = require('../config/kue');


module.exports.create = async function(req, res){
    try{
        let post = await Post.findById(req.body.post);
        if(post){
            let comment = await Comment.create({
                content: req.body.content,
                post: req.body.post,
                user: req.user._id
            });
            post.comments.push(comment);
            post.save();

            // comment = await comment.populate('user', 'name email').execPopulate();

                        
            // Create a job and save it to the queue
            const job = queue.createJob('emails', comment);

            // Save the job asynchronously
            job.save(function(err) {
                if (err) {
                    console.log('Error occurred:', err);
                    return;
                } else {
                    console.log('Job saved successfully. Job ID:', job.id);
                }
            });

            // commentsMailer.newComment(comment);
            
            if(req.xhr){
                return res.status(200).json({
                    data: {
                        comment: comment
                    },
                    message: "Comment created"
                });
            }
            
            req.flash('success', 'Comment Created successfully!');
            res.redirect('/');
        }
    }
    catch(err){
        console.log(err);
        req.flash('error', 'Cannot comment');
        res.status(500).send('Internal Server Error');
    }
}


// module.exports.create = function(req, res) {
//     Post.findById(req.body.post)
//         .then(post => {
//             if (post) {
//                 let comment = Comment.create({
//                     content: req.body.content,
//                     post: req.body.post,
//                     user: req.user._id
//                 })
//                 .then(comment => {
//                     post.comments.push(comment);
//                     // comment.populate(['user','name email']);
//                     // commentsMailer.newComment(comment);
//                     return post.save();
//                 })
//                 .then(() => {
//                     req.flash('success', 'Comment Created succesfully!');
//                     comment.populate('user', 'name email').execPopulate();

//                     res.redirect('/');
//                 })
//                 .catch(err => {
//                     req.flash('error', 'Cannot comment');
//                     console.log('err', err);
//                     res.status(500).send('Internal Server Error');
//                 });
//             } else {
//                 console.error('Post not found.');
//                 res.status(404).send('Post not found.');
//             }
//         })
//         .catch(err => {
//             console.error('Error while finding post:', err);
//             res.status(500).send('Internal Server Error');
//         });
// };


module.exports.destroy = async function(req, res) {
    try{
        let comment = await Comment.findById(req.params.id);
        if(comment.user == req.user.id){
            comment.deleteOne();

        await Like.deleteMany({likeable: comment._id, onModel: 'Comment'});

        // send the comment id which was deleted back to the views
        if (req.xhr){
            return res.status(200).json({
                data: {
                    comment_id: req.params.id
                },
                message: "Post deleted"
            });
        }
        // Comment.deleteMany({post: req.params.id})
        // .then(() => {

        req.flash('success', 'Comment Deleted succesfully!');
          return res.redirect('back');
        // })
      }
      else{
        req.flash('error', 'Unauthorized');
        return res.redirect('back');
      }
    }
    catch(err){
        req.flash('error', err);
        return;
    }
  }