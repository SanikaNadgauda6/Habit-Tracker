const Post = require('../models/post');
const User = require('../models/user');


module.exports.home = async function(req, res) {
  try{
    //populate the likes as well
      let posts = await Post.find({})
      .sort('-createdAt')
      .populate('user')
      .populate({
        path: 'comments',
        populate: {
          path: 'user'
        },
        populate: {
          path: 'likes'
        }
      }).populate('comments')
      .populate('likes');
    
      let users = await User.find({});

      return res.render('home', {
      title: "Codeial | Home",
      posts: posts,
      all_users: users
    });
  }
  catch{
        // console.log('Error in finding the posts:', err);
       req.flash('error', 'invalid username // password');
        // Handle the error and send an appropriate response to the client
        return res.status(500).json({ error: 'Error finding the posts' });

  }
}
     


// module.exports.actionName = function(req, res){}