const User = require("../models/user");
const fs = require('fs');
const path = require('path');


module.exports.profile = function(req, res){
    User.findById(req.params.id)
    .then((user) => {
            return res.render('user_profile', {
                title: 'User Profile',
                profile_user: user
            });
    });
    // if(!req.isAuthenticated()){
    //     console.log('I am here');
    //     return res.redirect('/users/sign-in');
    // }
}


module.exports.update = async function(req, res){
    if(req.user.id == req.params.id){
        try{
            let user = await User.findById(req.params.id);
            User.uploadedAvatar(req, res, function(err){
                if(err){console.log('******Multer Error: ', err)}

                user.name = req.body.email;
                user.email = req.body.email;
                if(req.file){

                    if (fs.existsSync(user.avatar)) {
                        fs.unlinkSync(user.avatar);
                        console.log('File deleted successfully');
                    } 

                    //this is saving the path of the uploaded file into the avatar field in the user
                    user.avatar = User.avatarPath + '/' + req.file.filename;
                } 
                user.save();
                return res.redirect('back');
            });
        }
        catch(err){
            req.flash('error', err);
            return res.redirect('back');

        }
        // User.findByIdAndUpdate(req.params.id, req.body)
        // .then(() => {
        //     return res.redirect('back');
        // })
        // .catch(() => {
        //     return res.status(401).send('Unauthorized');
        // });
    }
    else{
        req.flash('error', 'Unauthorized');
        return res.status(401).send('Unauthorized');
    }
}

//resder the sign up page
module.exports.signUp = function(req, res){
    if(req.isAuthenticated()){
        console.log('I am here1');
        return res.redirect('/users/profile');
    }   
    return res.render('user_Sign_up', {
        title: 'Codial | Sign Up'
    })
}

//render the sign in page
module.exports.signIn = function(req, res){
    if(req.isAuthenticated()){
        // console.log('I am here2');
        return res.redirect('/users/profile');
    } 
    return res.render('user_Sign_in', {
        title: 'Codial | Sign In'
    });
}


module.exports.create = function(req, res, callback){
    if(req.body.password != req.body.confirm_password){
        return res.redirect('back');
    }
    User.findOne({email: req.body.email})
        .then(function(user){
            if(!user){
                return User.create(req.body);
            } else {
                return Promise.reject('User already exists');
            }
        })
        .then(function(user){
            return res.redirect('/users/sign-in');
        })
        .catch(function(err){
            console.log('Error in signing up:', err);
            return res.redirect('/users/sign-up');
        });
};



module.exports.createSession = function(req, res){
    req.flash('success','Logged in succesfully');
    return res.redirect('/');
}


module.exports.destroySession = function(req, res) {
    new Promise((resolve, reject) => {
      req.logout((err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    })
    .then(() => {
        req.flash('success','Logged Out succesfully');
        res.redirect('/');
    })
    .catch((err) => {
      console.error('Error while logging out:', err);
      res.redirect('/error'); // Redirect to an error page if logout fails
    });
  };


//render the forgot password page
module.exports.forgotPassword = function(req, res){
    if(req.isAuthenticated()){
        console.log('I am here in forgot password rendering');
        return res.redirect('/users/forgotPassword');
    } 
    return res.render('forgot_password', {
        title: 'Codial | Forgot Password? '
    });
}
  
  //this is post method
module.exports.changePassword = async function(req, res){
    console.log('I am hereeeeeeee');
    try {
        if (req.body.password !== req.body.confirm_password) {
            console.log('Passwords do not match.');
            return res.redirect('back');
        }

        const user = await User.findOne({email: req.body.email});
        // console.log(user);
        if (!user) {
            console.log('User not found.');
            req.flash('error','User not found.');
            return res.redirect('/users/sign-up'); // Redirect to sign-up page or appropriate route
        }

  
        // Update the password field directly
        user.password = req.body.password; // Make sure to hash the password before storing it

        await user.save();
        req.flash('success','Password updated succesfully');
        console.log('Password updated successfully.');
        return res.redirect('/users/sign-in'); // Redirect to sign-in page or appropriate route
    } 
    
    catch (err) {
        req.flash('error', 'Unauthorized');
        console.log('Error in updating password:', err);
        return res.status(401).send('Unauthorized');
        // return res.redirect('back'); // Redirect back on error
    }
};




