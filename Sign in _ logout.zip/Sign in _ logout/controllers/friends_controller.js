const Friendship = require('../models/friendship');
const Post = require('../models/post');
const Comment = require('../models/comments');

const mongoose = require('mongoose');


module.exports.friendstoggle = async function(req, res){
    try{
        //friendships/toggle/?id=abcd1234&type=Post

        let friendship;
        let deleted = false;

        if(req.query.type == 'Post'){
            friendship = await Post.findById(req.query.id).populate('Friendship');
        }
        else{
            friendship = await Comment.findById(req.query.id).populate('Friendship');
        }

        //check if a like already exists
        let existingfriend = await Friendship.findOne({
            friendship: req.query.id,
            onModel: req.query.type,
            user: new mongoose.Types.ObjectId(req.user._id) // Use mongoose.Types.ObjectId
        });



        if(existingfriend) {
            console.log("I am inside existing like", existingfriend);
            let pullreq = friendship.friendships.pull(existingfriend._id);
            console.log("this is a pull request..............",pullreq);
            friendship.save();

            existingfriend.deleteOne();
            deleted = true;
            console.log('Friend deleted successfully');
            if (req.xhr) {
                return res.status(200).json({
                    data: {
                        deleted: true,
                    },
                    message: "Friend deleted successfully",
                });
            }
        }
        else {
            // This block is executed if no existing like is found
        
            let newFriend = await Like.create({
                user: req.user._id,
                friendship: req.query.id,
                onModel: req.query.type
            });
        
            friendship.friendships.push(newFriend._id);
            friendship.save();
        
            console.log('Like created');
            if (req.xhr) {
                return res.status(200).json({
                    data: {
                        deleted: false,
                    },
                    message: "Like added successfully",
                });
            }
        }

    }
    catch(err){
        console.log('Error Occured:', err);
        return res.json(500, {
            message: 'Internal Server Error'
        });
    }
}