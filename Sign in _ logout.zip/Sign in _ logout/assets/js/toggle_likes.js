class ToggleLike {
    constructor(toggleElement) {
        this.toggler = toggleElement;
        this.toggleLike();
    }

    toggleLike() {
        const self = this; // Store a reference to the class instance

        $(this.toggler).click((e) => {
            e.preventDefault();
            const likesCountElement = $(self.toggler).find('.likes-count');
            let likesCount = parseInt(likesCountElement.text());

            $.ajax({
                type: 'POST',
                url: $(self.toggler).attr('href'),
            })
            .done(function (data) {
                if (data.success) {
                    $(self.toggler).toggleClass('liked');

                    if (data.deleted) {
                        likesCount -= 1;
                    } else {
                        likesCount += 1;
                    }

                    likesCountElement.text(likesCount);
                } else {
                    console.log('Server returned an error:', data.error);
                }
            })
            .fail(function (errData) {
                console.log('Error in completing the request:', errData);
            });
        });
    }
}
