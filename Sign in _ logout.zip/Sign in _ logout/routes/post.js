const express = require('express');
const router = express.Router();
// console.log('post router loaded');
const passport = require('passport');

const PostController = require('../controllers/post_controller');


router.post('/create', passport.checkAuthentication, PostController.create);
router.get('/destroy/:id', passport.checkAuthentication, PostController.destroy);

module.exports = router;