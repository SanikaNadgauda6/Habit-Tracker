const Like = require('../models/likes');
const Post = require('../models/post');
const Comment = require('../models/comments');

const mongoose = require('mongoose');


module.exports.toggleLikes = async function(req, res){
    try{
        //likes/toggle/?id=abcd1234&type=Post

        let likeable;
        let deleted = false;

        if(req.query.type == 'Post'){
            likeable = await Post.findById(req.query.id).populate('likes');
        }
        else{
            likeable = await Comment.findById(req.query.id).populate('likes');
        }

        //check if a like already exists
        let existingLike = await Like.findOne({
            likeable: req.query.id,
            onModel: req.query.type,
            user: new mongoose.Types.ObjectId(req.user._id) // Use mongoose.Types.ObjectId
        });
        
        // console.log(existingLike);
        // console.log("likeable", req.query.id);
        // console.log("Onmodel", req.query.type);
        // console.log("user", req.user._id);

        //if a like already exist then delete it
        //console.log(typeof existingLike); // Should be 'object' if it's a Mongoose instance

        // if (existingLike) {




        if(existingLike) {
            // console.log("I am inside existing like", existingLike);
            let pullreq = likeable.likes.pull(existingLike._id);
            // console.log("this is a pull request..............",pullreq);
            likeable.save();

            existingLike.deleteOne();
            deleted = true;
            console.log('Like deleted successfully');
            if (req.xhr) {
                return res.status(200).json({
                    data: {
                        deleted: true,
                    },
                    message: "Like deleted successfully",
                });
            }
        }
        else {
            // This block is executed if no existing like is found
        
            let newLike = await Like.create({
                user: req.user._id,
                likeable: req.query.id,
                onModel: req.query.type
            });
        
            likeable.likes.push(newLike._id);
            likeable.save();
        
            console.log('Like created');
            if (req.xhr) {
                return res.status(200).json({
                    data: {
                        deleted: false,
                    },
                    message: "Like added successfully",
                });
            }
        }

    }
    catch(err){
        console.log('Error Occured:', err);
        return res.json(500, {
            message: 'Internal Server Error'
        });
    }
}