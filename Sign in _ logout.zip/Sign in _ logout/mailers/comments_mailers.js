const nodeMailer = require('../config/nodemailer');
const User = require('../models/user');


exports.newComment = async (comment) => {

    const user = await User.findById(comment.user);
    let htmlString = nodeMailer.renderTemplate({comment: comment, user: user}, '/comments/new_comment.ejs');
    nodeMailer.transporter.sendMail({
        from: 'snadgauda17@gmail.com',
        to: user.email,
        subject: "New comment Published!",
        html: htmlString
    },
    
    (err, info)=> {
        if(err){
            console.log("Error occured!", err);
            return;
        }
        console.log("Message Sent", info);
        return;
    });

}